package defaultpackage;

import javax.swing.JFrame;

import partie1.RepartitionFrame;
import partie2.*;


public class Main {

    public static void main(String [] args) throws Exception {

        Enseignant prudence = new EnseignantImpl("Prudence", "Michel");
        Enseignant muzumbo = new EnseignantImpl("Muzumbo", "Kanida");
        EnseignantImpl lourme = new EnseignantImpl("Lourme", "Alex");
        EnseignantAvecStatut baudon = new EnseignantAvecStatut("Baudon", "Olivier", "Chef");

        Matiere rechercheOp = new Matiere("rechercheOp");
        Matiere sgbd = new Matiere("sgbd");
        Matiere maths = new Matiere("maths");
        Matiere poo = new Matiere("poo");

        Repartition repartition = new Repartition(rechercheOp, sgbd, maths, poo);

        repartition.affecterMatiere(rechercheOp, muzumbo);
        repartition.affecterMatiere(maths,lourme);
        repartition.affecterMatiere(sgbd, prudence);
        repartition.affecterMatiere(poo,baudon);

        JFrame f = new RepartitionFrame(repartition);
        f.pack();
        f.setVisible(true);
    }
}