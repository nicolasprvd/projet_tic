package partie1;
import partie2.Repartition;

import java.awt.*;

import javax.swing.*;


public class RepartitionFrame extends JFrame{
    public RepartitionFrame(Repartition repartition) {
        super("Repartition");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JTextArea textArea = new JTextArea();
        textArea.setPreferredSize(new Dimension(100,50));
        textArea.setEditable(false);
        add(textArea, BorderLayout.CENTER);


        JPanel panel1 = new JPanel();
        panel1.setLayout(new BorderLayout());
        JTextField texte = new JTextField(10);
        panel1.add(texte);

        JPanel panel2 = new JPanel();
        panel2.setLayout(new GridLayout(0,1));
        JButton b = new JButton("Ok");
        b.addActionListener(new AfficherListener(texte, repartition, textArea));
        panel2.add(b);

        panel1.add(panel2, BorderLayout.SOUTH);
        add(panel1, BorderLayout.WEST);



    }
}