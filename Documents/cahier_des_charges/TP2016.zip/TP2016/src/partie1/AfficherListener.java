package partie1;
import partie2.Enseignant;
import partie2.Matiere;
import partie2.Repartition;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;


public class AfficherListener implements ActionListener {
    private JTextField texte;
    private Repartition repartition;
    private JTextArea textArea;

    public AfficherListener(JTextField texte, Repartition repartition, JTextArea textArea) {
        this.texte = texte;
        this.repartition = repartition;
        this.textArea = textArea;
    }


    @Override
    public void actionPerformed(ActionEvent arg0) {
        // Question 3
        //System.out.println(texte.getText());


        // Question 8
        //Enseignant e = repartition.enseignant(new Matiere(texte.getText()));
        //if (e != null)
        //    System.out.println(e);
        //else
        //    System.out.println("Matière non affectée");

        //Question 11
        Enseignant e = repartition.enseignant(new Matiere(texte.getText()));
        if (e != null)
            textArea.append(e.toString() + "\n");
        else
            textArea.append("Matière non affectée" + "\n");

}
}