package partie1;

// Question 9

import partie2.Matiere;

public class MatiereInexistanteException extends Exception {

    private Matiere E;

    public MatiereInexistanteException(Matiere E) {
        this.E = E;
    }

    public String getMessage() {
        return E.nom() + " inexistante !";
    }


}
