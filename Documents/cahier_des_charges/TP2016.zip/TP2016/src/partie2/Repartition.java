package partie2;

import partie1.MatiereInexistanteException;

import java.util.HashMap;
import java.util.Map;

public class Repartition {
    private Map<Matiere, Enseignant> repartition;

    public Repartition(Matiere... matieres) {
        repartition = new HashMap<Matiere, Enseignant>();
        for (Matiere m : matieres) {
            repartition.put(m, null);
        }
    }

    public Enseignant enseignant(Matiere matiere) {
        return repartition.get(matiere);
    }

    public void affecterMatiere(Matiere m, Enseignant e) throws MatiereInexistanteException{

        //Question 9
        if (repartition.containsKey(m))
            repartition.put(m, e);
        else
           throw new MatiereInexistanteException(m);

    }
}