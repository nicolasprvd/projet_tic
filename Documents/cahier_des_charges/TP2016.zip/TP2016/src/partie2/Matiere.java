package partie2;

import static java.util.Objects.hash;

public class Matiere {

    private String nom;

    public Matiere(String nom) {
        this.nom = nom;
    }

    public String nom() {
        return nom;
    }

    // Question 6
    public boolean equals(Object o) {
        if (!(o instanceof Matiere))
            return false;
        return nom.equals(((Matiere) o).nom);
    }

    // Question 6
    public int hashCode() {
        return hash(nom);
    }

}