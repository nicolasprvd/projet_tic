package partie2;

// Question 7
public class EnseignantAvecStatut extends  EnseignantImpl{

    private String statut;

    public EnseignantAvecStatut(String nom, String prenom, String statut) {
        super(nom, prenom);
        this.statut = statut;
    }

    @Override
    public String toString() {
        return super.toString() + " Statut : " + statut;
    }
}
