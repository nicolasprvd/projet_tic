package partie2;

public interface Enseignant {
    public String nom();

    public String prenom();
}