import javax.swing.JButton;
import javax.swing.JFrame;

import bouton.BoutonCirculaire;
import bouton.BoutonIterateur;
import circularlist.CircularListIterator;

public class TestBoutonCirculaireAvecListe {
	public static void main(String[] args) {
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				CircularListIterator<String> cli = new CircularListIterator<>("a", "z", "e", "r", "t", "y");
				JFrame f = new JFrame(BoutonIterateur.BOUTON_ITERATEUR);
				JButton b = new BoutonCirculaire(cli);
				f.getContentPane().add(b);
				f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				f.pack();
				f.setLocationRelativeTo(null);
				f.setVisible(true);
			}
		});
	}
}
