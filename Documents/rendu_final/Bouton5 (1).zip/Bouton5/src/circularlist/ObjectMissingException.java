package circularlist;

public class ObjectMissingException extends Exception {

	private static final long serialVersionUID = 1L;

	private Object o;

	public ObjectMissingException(Object o) {
		this.o = o;
	}

	public Object missingObject() {
		return o;
	}

	public String getMessage() {
		return "Object " + o + " is missing";
	}

}
