package circularlist;

import java.util.Iterator;
import java.util.function.Consumer;

import circularlist.CircularListImpl;

//Adaptateur d'objets instances de la classe CircularList vers Iterator
public class CircularListIterator2<E> implements Iterator<E> {

	private CircularList<E> delegue;

	public CircularListIterator2(CircularList<E> cl) {
		this.delegue = cl;
	}

	public boolean hasNext() {
		return delegue.size() != 0;
	}

	public E next() {
		return delegue.nextElement();
	}

	public void forEachRemaining(Consumer<? super E> action) {
		throw new UnsupportedOperationException();
	}

	public static void main(String[] args) {
		CircularList<Integer> cl = new CircularListImpl<Integer>(22, 16, 141, 17);
		Iterator<Integer> iti = new CircularListIterator2<Integer>(cl);
		int i = 0;
		while (iti.hasNext() && i < 10) {
			System.out.println(iti.next());
			i++;
		}
	}

}
