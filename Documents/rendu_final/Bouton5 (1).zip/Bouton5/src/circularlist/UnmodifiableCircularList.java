package circularlist;

class UnmodifiableCircularList<E> implements CircularList<E> {
	private CircularList<? extends E> list;
	
	public UnmodifiableCircularList(CircularList<? extends E> l) {
		if (l == null)
			throw new NullPointerException();
		list = l;
	}
	
	public E get(int i) {
		return list.get(i);
	}

	public int indexOf(Object element) throws ObjectMissingException {
		return list.indexOf(element);
	}

	public int size() {
		return list.size();
	}
	
	public String toString() {
		return list.toString();
	}

	public E nextElement() {
		return list.nextElement();
	}

	public void add(int index, E element) {
		throw new UnsupportedOperationException();
	}

	public boolean add(E element) {
		throw new UnsupportedOperationException();
	}
	
	public boolean addAll(CircularList<? extends E> cl) {
		if (cl.size() == 0)
			return false;
		throw new UnsupportedOperationException();		
	}


	public boolean equals(Object o) {
		return list.equals(o);
	}

	public int hashCode() {
		return list.hashCode();
	}
}
