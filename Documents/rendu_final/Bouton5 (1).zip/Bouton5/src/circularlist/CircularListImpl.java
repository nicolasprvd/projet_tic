package circularlist;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class CircularListImpl<E> implements CircularList<E> {
	private List<E> elements;
	private int index;

	@SafeVarargs
	public CircularListImpl(E... elements) {
		this.elements = new ArrayList<E>(Arrays.asList(elements));
		index = -1;
	}

	/** get the element at index i % size(). */
	public E get(int i) {
		return elements.get(i % elements.size());
	}

	/**
	 * return the first index of the object o in the circular list,
	 * 
	 * @throws ObjectMissingException
	 *             - if the object is not present
	 */
	public int indexOf(Object element) throws ObjectMissingException {
		int index = elements.indexOf(element);
		if (index == -1)
			throw new ObjectMissingException(element);
		return index;
	}

	/** number of elements contained in the circular list. */
	public int size() {
		return elements.size();
	}

	public String toString() {
		return "Circular List of size " + size();
	}

	public E nextElement() {
		index = ++index % elements.size();
		return get(index);
	}

	public void add(int index, E element) {
		elements.add(index, element);
	}

	public boolean add(E element) {
		return elements.add(element);
	}

	public boolean addAll(CircularList<? extends E> cl) {
		boolean result = true;
		for (int i = 0; i < cl.size(); i++) 
			result &= add(cl.get(i));
		return result;
	}

	public boolean equals(Object o) {
		if (!(o instanceof CircularListImpl))
			return false;
		CircularListImpl<?> cl = (CircularListImpl<?>) o;

		return elements.equals(cl.elements);
	}

	public int hashCode() {
		return elements.hashCode();
	}

}