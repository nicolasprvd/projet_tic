package circularlist;

import java.util.Iterator;
import java.util.function.Consumer;

import circularlist.CircularListImpl;

//Adaptateur de classe de la classe CircularList vers Iterator
public class CircularListIterator<E> extends CircularListImpl<E> implements Iterator<E> {

	@SafeVarargs
	public CircularListIterator(E... elements) {
		super(elements);
	}

	public boolean hasNext() {
		return size() != 0;
	}

	public E next() {
		return nextElement();
	}

	public void forEachRemaining(Consumer<? super E> action) {
		throw new UnsupportedOperationException();
	}

	public static void main(String[] args) {
		CircularListIterator<Integer> cl = new CircularListIterator<Integer>(22, 16, 141, 17);
		int i = 0;
		while (cl.hasNext() && i < 10) {
			System.out.println(cl.next());
			i++;
		}
	}

}
