package circularlist;

public interface CircularList<E> {

	public abstract E get(int i);

	public abstract int indexOf(Object element) throws ObjectMissingException;

	public abstract int size();

	public abstract String toString();

	public abstract E nextElement();

	public abstract void add(int index, E element);

	public abstract boolean add(E element);

	public boolean addAll(CircularList<? extends E> cl);

	public abstract boolean equals(Object o);

	public abstract int hashCode();

}