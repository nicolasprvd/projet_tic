package circularlist;

public class CircularLists {

	public static <E> CircularList<E> union(CircularList<? extends E> cl1, CircularList<? extends E> cl2) {
		CircularList<E> union = new CircularListImpl<>();
		union.addAll(cl1);
		union.addAll(cl2);		
		return union;
	}
	
	public static <E> CircularList<E> unmodifiableCircularList(CircularList<? extends E> cl) {
		return new UnmodifiableCircularList<E>(cl);
	}
}
