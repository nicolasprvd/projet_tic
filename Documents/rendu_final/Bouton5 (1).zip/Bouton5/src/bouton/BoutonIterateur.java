package bouton;
import java.util.Iterator;

import javax.swing.JButton;

public class BoutonIterateur extends JButton {

	public static String BOUTON_ITERATEUR = "Bouton avec Iterateur";

	public BoutonIterateur(Iterator<?> it) {
		if (! it.hasNext()) 
			throw new IllegalArgumentException();
		setText(it.next().toString());
		addActionListener(e -> {
			System.out.println(this.getText());
			if (it.hasNext()) 
				this.setText(it.next().toString());
			else 
				System.exit(0);
		});
	}
}
