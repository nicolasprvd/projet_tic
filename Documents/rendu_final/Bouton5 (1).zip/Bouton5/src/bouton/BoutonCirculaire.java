package bouton;
import circularlist.CircularListIterator;

public class BoutonCirculaire extends BoutonIterateur {

	public BoutonCirculaire(CircularListIterator<?> it) {
		super(it);
	}
}
