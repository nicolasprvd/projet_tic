package animal;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class ZoologieFrame extends JFrame {
	private static final long serialVersionUID = 1L;

	public ZoologieFrame(Zoologie zoo, Animaux animaux) {
		super("Especes");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		// Question 12
		JList<Espece> liste = new JList<Espece>();
		liste.addListSelectionListener(e -> {
			if (e.getValueIsAdjusting())
				return;
			for (Animal a : animaux.animauxParEspece(liste.getSelectedValue()))
					System.out.println(a);
		});
		
		liste.setListData(new Vector<Espece>(zoo.especes()));
		this.add(liste);
		liste.setSelectedIndex(0);
		JPanel panel = new JPanel();
		panel.setLayout(new GridLayout(0, 1));
		JTextField texte = new JTextField();
		panel.add(texte);
		JButton b = new JButton("Ok");
		panel.add(b);
		b.addActionListener(new ZoologieListener(liste, texte, animaux));
		add(panel, BorderLayout.SOUTH);
	}
}
