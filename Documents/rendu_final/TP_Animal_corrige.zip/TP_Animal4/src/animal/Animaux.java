package animal;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

public class Animaux {
	private Map<Espece, Set<Animal>> animaux = new HashMap<>();
	
	public Animal creerAnimal(String nom, Espece e) throws AnimalExistantException {
		Set<Animal> s = animaux.get(e);
		Animal a = new Animal(nom, e);
		if (s == null) {
			s = new HashSet<Animal>();
			animaux.put(e, s);
		} else if (s.contains(a)) {
			throw new AnimalExistantException(a);
		}
		s.add(a);
		return a;
	}
	
	// Question 11
	@SuppressWarnings("unchecked")
	public Collection<Animal> animauxParEspece(Espece e) {
		Set<Animal> s = animaux.get(e);
		if (s == null) {
			s = Collections.EMPTY_SET;
		}
		return Collections.unmodifiableCollection(s);
	}
}
