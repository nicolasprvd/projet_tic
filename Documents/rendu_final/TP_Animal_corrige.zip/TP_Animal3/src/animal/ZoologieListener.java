package animal;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JList;
import javax.swing.JTextField;


public class ZoologieListener implements ActionListener {

	private JList<Espece> liste;
	private JTextField texte;
	private Animaux animaux;
	
	public ZoologieListener(JList<Espece> liste, JTextField texte, Animaux animaux) {
		this.liste = liste;
		this.texte = texte;
		this.animaux = animaux;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// Reponse Q5
		// System.out.println(liste.getSelectedValue());

		// Reponse Q7
		// new Animal(texte.getText(), liste.getSelectedValue());
		// texte.setText("");
		
		// Modification Q8	
		try {
			Animal a = animaux.creerAnimal(texte.getText(), liste.getSelectedValue());
			System.out.println(a);
		} catch (AnimalExistantException e) {
			System.out.println(e.getMessage());
		}
		texte.setText("");
	}
}
