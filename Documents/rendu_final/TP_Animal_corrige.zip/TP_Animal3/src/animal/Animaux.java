package animal;

import java.util.HashSet;
import java.util.Set;

public class Animaux {
	private Set<Animal> animaux = new HashSet<>();
	
	public Animal creerAnimal(String nom, Espece e) throws AnimalExistantException {
		Animal a = new Animal(nom, e);
		if (animaux.contains(a)) 
			throw new AnimalExistantException(a);
		animaux.add(a);
		return a;
	}
}
