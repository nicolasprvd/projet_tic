package animal;

public class AnimalExistantException extends Exception {

	private Animal animal;
	
	public AnimalExistantException(Animal a) {
		super("Animal " + a + " déja existant");
		this.animal = a;
	}
	
	public Animal animal() {
		return animal;
	}
}
