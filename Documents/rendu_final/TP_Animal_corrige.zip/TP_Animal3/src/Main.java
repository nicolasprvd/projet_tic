import javax.swing.JFrame;

import animal.Animal;
import animal.AnimalExistantException;
import animal.Animaux;
import animal.Espece;
import animal.Zoologie;
import animal.ZoologieFrame;


public class Main {

	public static void main(String [] args) throws AnimalExistantException {
		Espece chat = new Espece("Chat");
		Animaux animaux = new Animaux();
		Animal simba = animaux.creerAnimal("Simba", chat);
		System.out.println(simba);
		Espece chien = new Espece("Chien");
		Espece poisson = new Espece("Poisson");
		Zoologie zoo = new Zoologie(chat, chien, poisson);
		JFrame f = new ZoologieFrame(zoo, animaux);
		f.pack();
		f.setLocationRelativeTo(null);
		f.setVisible(true);
	}
}
