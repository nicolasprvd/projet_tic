import javax.swing.JFrame;

import animal.Animal;
import animal.Espece;
import animal.Zoologie;
import animal.ZoologieFrame;


public class Main {

	public static void main(String [] args) {
		Espece chat = new Espece("Chat");
		Espece chien = new Espece("Chien");
		Espece poisson = new Espece("Poisson");
		Zoologie zoo = new Zoologie(chat, chien, poisson);
		JFrame f = new ZoologieFrame(zoo);
		f.pack();
		f.setLocationRelativeTo(null);
		f.setVisible(true);
	}
}
