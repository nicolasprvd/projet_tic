package animal;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class Zoologie {
	public Set<Espece> especes;

	public Zoologie(Espece... especes) {
		this.especes = new HashSet<Espece>(Arrays.asList(especes));
	}

	public void ajouterEspece(Espece e) {
		especes.add(e);
	}
	
	public Set<Espece> especes() {
		return Collections.unmodifiableSet(especes);
	}
}
