package animal;

public class Animal {

	private String nom;
	private Espece espece;
	
	public Animal(String nom, Espece espece) {
		this.nom = nom;
		this.espece = espece;
	}
	
	public String nom() {
		return nom;
	}
	
	public Espece espece() {
		return espece;
	}
}
