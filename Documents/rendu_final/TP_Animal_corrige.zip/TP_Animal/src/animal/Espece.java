package animal;

public class Espece {

	private String nom;
	
	public Espece(String nom) {
		this.nom = nom;
	}
	
	public String nom() {
		return nom;
	}
	
	public String toString() {
		return nom;
	}
}
