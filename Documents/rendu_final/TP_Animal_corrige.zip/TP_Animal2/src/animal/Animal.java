package animal;

import java.util.Objects;

public class Animal {

	private String nom;
	private Espece espece;

	public Animal(String nom, Espece espece) {
		this.nom = nom;
		this.espece = espece;
	}

	public String nom() {
		return nom;
	}

	public Espece espece() {
		return espece;
	}

	// Question 3
	public String toString() {
		return nom + " (" + espece + ")";
	}

	// Question 4 : equals + hashCode
	public boolean equals(Object o) {
		if (!(o instanceof Animal))
			return false;
		Animal a = (Animal) o;
		return espece.equals(a.espece) && nom.equals(a.nom);
	}
	
	public int hashCode() {
		return Objects.hash(espece, nom);
	}
}
