package animal;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JList;
import javax.swing.JTextField;


public class ZoologieListener implements ActionListener {

	private JList<Espece> liste;
	private JTextField texte;
	
	public ZoologieListener(JList<Espece> liste, JTextField texte) {
		this.liste = liste;
		this.texte = texte;
	}

	@Override
	public void actionPerformed(ActionEvent arg0) {
		// Reponse Q5
		// System.out.println(liste.getSelectedValue());

		// Reponse Q7
		Animal a = new Animal(texte.getText(), liste.getSelectedValue());
		System.out.println(a);
	}
}
