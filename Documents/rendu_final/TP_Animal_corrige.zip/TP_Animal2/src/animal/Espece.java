package animal;

import java.util.Objects;

public class Espece {

	private String nom;
	
	public Espece(String nom) {
		this.nom = nom;
	}
	
	public String nom() {
		return nom;
	}
	
	public String toString() {
		return nom;
	}
	
	// Question 4 : equals + hashCode
	public boolean equals(Object o) {
		if (! (o instanceof Espece))
			return false;
		return nom.equals(((Espece) o).nom());
	}
	
	public int hashCode() {
		return Objects.hash(nom);
	}
}
