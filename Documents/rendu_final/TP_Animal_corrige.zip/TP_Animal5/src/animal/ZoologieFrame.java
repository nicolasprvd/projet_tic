package animal;
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

public class ZoologieFrame extends JFrame {
	private static final long serialVersionUID = 1L;

	public ZoologieFrame(Zoologie zoo, Animaux animaux) {
		super("Especes");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		// Question 13
		
		JTextArea area = new JTextArea();
		area.setEditable(false);
		area.setPreferredSize(new Dimension(100,100));
		add(area, BorderLayout.CENTER);

		JPanel panel1 = new JPanel();
		panel1.setLayout(new BorderLayout());
		JList<Espece> liste = new JList<Espece>();
		liste.setListData(new Vector<Espece>(zoo.especes()));
		liste.setSelectedIndex(0);
		liste.addListSelectionListener(e -> {
			if (e.getValueIsAdjusting())
				return;
			area.setText("");
			for (Animal a : animaux.animauxParEspece(liste.getSelectedValue()))
				area.append(a.toString() + "\n");
		});
		panel1.add(liste);
		
		JPanel panel2 = new JPanel();
		panel2.setLayout(new GridLayout(0, 1));
		JTextField texte = new JTextField();
		panel2.add(texte);
		JButton b = new JButton("Ok");
		panel2.add(b);
		b.addActionListener(new ZoologieListener(liste, texte, animaux));
		panel1.add(panel2, BorderLayout.SOUTH);
		add(panel1, BorderLayout.WEST);
	}
}
